#include "funciones.h"
float ingresarNum(float num)
{
    printf("Por favor ingrese un numero \n");
    scanf("%f",&num);
    return num;
}

float suma(float num1,float num2,int flag,int flag1)
{
    float resultado;
    if(validacionO(flag,flag1)==0)
    {

        printf("Por favor ingrese el operando faltante para poder realizar la operacion \n");
    }
    else
    {
        resultado=(num1+num2);


        printf("La suma es: %.2f \n",resultado);
        return resultado;
    }

    return 0;
}
float resta(float num1,float num2,int flag,int flag1)
{
    float resultado;
    if(validacionO(flag,flag1)==0)
    {

        printf("Por favor ingrese el operando faltante para poder realizar la operacion \n");
    }
    else
    {
        resultado=(num1-num2);
        printf("La resta es: %.2f \n",resultado);
        return resultado;
    }
    return 0;


}
float divicion(float num1,float num2,int flag,int flag1)
{
    float resultado;

    if(validacionO(flag,flag1)==0)
    {

        printf("Por favor ingrese el operando faltante para poder realizar la operacion \n");
    }
    else
    {
        if(num1<1||num2<1)
        {
            printf("por favor vuelva a introducir un operando mayor a 0\n");
        }
        else
        {

            resultado=(num1/num2);


            printf("La divicion  es: %.2f \n",resultado);
        }
        return resultado;
    }



}
float multiplicacion(float num1,float num2,int flag,int flag1)
{  float resultado;
    if(validacionO(flag,flag1)==0)
    {

        printf("Por favor ingrese el operando faltante para poder realizar la operacion \n");
    }
    else
    {
        resultado=(num1*num2);

        printf("El producto es: %.2f \n",resultado);
        return resultado;
    }



}
long long int factorial(float num1)
{


    long long int resultado;

    if((int)num1==0)
    {

        return 1;
    }


    resultado = (int)num1 * factorial((int)num1-1);

    return resultado;


}

float todasOperaciones(float num1,float num2,int flag, int flag1)
{
    float sumar;
    float restar;
    float div;
    float multi;
    long long int fac;
    float valF;
    int operaciones=0;

    sumar=suma(num1,num2,flag,flag1);
    restar=resta(num1,num2,flag,flag1);
    div=divicion(num1,num2,flag,flag1);
    multi=multiplicacion(num1,num2,flag,flag1);
    fac=factorial(num1);
    valF=validacionF2(flag,flag1,num1,fac);
    operaciones=1;



    return operaciones;
}
int validacionO(int flag,int flag1)
{
    int Flags=1;
    if(flag!=1||flag1!=1)
    {

        Flags=0;
    }


    return Flags;

}
int validacionF2(int flag,int flag1,float num1,long long int fac)
{
    int aux;
    float resultado;
    aux= num1;
    resultado=(num1-aux);
    if(resultado!=0)
    {
        printf("No se puede realizar el factorial de un numero con coma\n");
        system("pause");
        system("cls");

    }


    int val;
    if(flag==1&&flag1==0)
    {
        if(num1>0)
        {
            printf("El factorial es %lld \n ",fac);
            system("pause");
            system("cls");

        }
        else
        {
            printf("Por favor ingresar un numero mayor a 0\n");
            system("pause");
            system("cls");

        }
    }
    else
    {
        //val=validacionF(flag,flag1);
        if(flag==0&&flag1==1)
        {
            printf("Por favor para realizar el factorial introduzca el operando uno\n");
            system("pause");
            system("cls");
        }
        else
        {
            if(flag==1&&flag1==1)
            {
                printf("Se han ingresado ambos operandos pero solo se calculara el factorial del primero\n");
                system("pause");
                system("cls");
                printf("El factorial es %lld \n ",fac);
                system("pause");
                system("cls");



            }
        }
    }
    return fac;
}

float menu(int flag,int flag1,float num1,float num2)
{
    float opcion;
    char VerifLetra;
    int Letra;
    int aux;
    float resultado;
    aux=opcion;
    resultado=(opcion-aux);

    if(flag==1&&flag1==0)
    {
        printf("1- Ingresar 1er operando (A= %.2f)\n",num1);
        printf("2- Ingresar 2do operando (B=y)\n");
        printf("3- Calcular la suma (A+B)\n");
        printf("4- Calcular la resta (A-B)\n");
        printf("5- Calcular la division (A/B)\n");
        printf("6- Calcular la multiplicacion (A*B)\n");
        printf("7- Calcular el factorial (A!)\n");
        printf("8- Calcular todas las operaciones\n");
        printf("9- Salir\n");

        printf("Ingrese una opcion: ");
        scanf("%f",&opcion);

        system("pause");
        system("cls");
        while(opcion<1||opcion>9)
        {
            printf("Por favor ingrese una opcion entre 1-9\n");
            scanf("%f",& opcion);
            system("pause");
            system("cls");

        }



    }
    else
    {
        if(flag1==1&&flag==0)
        {
            printf("1- Ingresar 1er operando (A=x)\n");
            printf("2- Ingresar 2do operando (B= %.2f)\n",num2);
            printf("3- Calcular la suma (A+B)\n");
            printf("4- Calcular la resta (A-B)\n");
            printf("5- Calcular la division (A/B)\n");
            printf("6- Calcular la multiplicacion (A*B)\n");
            printf("7- Calcular el factorial (A!)\n");
            printf("8- Calcular todas las operaciones\n");
            printf("9- Salir\n");
            printf("Ingrese una opcion: ");
            scanf("%f",&opcion);

            system("pause");
            system("cls");
            while(opcion<1||opcion>9)
            {
                printf("Por favor ingrese una opcion entre 1-9\n");
                scanf("%f",&opcion);
                system("pause");
                system("cls");

            }

        }
        else
        {
            if(flag==1&&flag1==1)
            {
                char respuesta='s';
                printf("1- Ingresar 1er operando (A= %.2f)\n",num1);
                printf("2- Ingresar 2do operando (B= %.2f)\n",num2);
                printf("3- Calcular la suma (A+B)\n");
                printf("4- Calcular la resta (A-B)\n");
                printf("5- Calcular la division (A/B)\n");
                printf("6- Calcular la multiplicacion (A*B)\n");
                printf("7- Calcular el factorial (A!)\n");
                printf("8- Calcular todas las operaciones\n");
                printf("9- Salir\n");
                printf("Ingrese una opcion: ");
                scanf("%f",&opcion);


                system("pause");
                system("cls");
                while(opcion<1||opcion>9)
                {
                    printf("Por favor ingrese una opcion entre 1-9\n");
                    scanf("%f",&opcion);
                    system("pause");
                    system("cls");

                }


            }
            else
            {
                printf("1- Ingresar 1er operando (A=x)\n");
                printf("2- Ingresar 2do operando (B=y)\n");
                printf("3- Calcular la suma (A+B)\n");
                printf("4- Calcular la resta (A-B)\n");
                printf("5- Calcular la division (A/B)\n");
                printf("6- Calcular la multiplicacion (A*B)\n");
                printf("7- Calcular el factorial (A!)\n");
                printf("8- Calcular todas las operaciones\n");
                printf("9- Salir\n");

                printf("Ingrese una opcion: ");
                scanf("%f",&opcion);

                system("pause");
                system("cls");
                while(opcion<1||opcion>9)
                {
                    printf("Por favor ingrese una opcion entre 1-9 \n");
                    scanf("%f",&opcion);
                    system("pause");
                    system("cls");


                }




            }
        }
    }
    return opcion;
}






