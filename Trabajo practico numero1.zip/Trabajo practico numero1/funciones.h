#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

/** \brief solicita un operando y lo retorna
 * \return Operando  ingresado por el usuario
 */
float ingresarNum(float);
//********************************************************
/** \brief Recibe el operando uno y el operando dos y calcula la suma
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
*  \param flag se utiliza para saber si fue ingresado o no el primer operando
*  \param flag1 se utiliza para saber si fue ingresado o no el segundo operando
* \return resultado de la suma
*/
float suma(float,float,int,int);
//********************************************************
/** \brief Recibe el operando uno y el operando dos y calcula la resta
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
*  \param flag se utiliza para saber si fue ingresado o no el primer operando
*  \param flag1 se utiliza para saber si fue ingresado o no el segundo operando
* \return resultado de la resta
*/
float resta(float,float,int,int);
//********************************************************
/** \brief Recibe el operando uno y el operando dos y calcula la division
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
*  \param flag se utiliza para saber si fue ingresado o no el primer operando
*  \param flag1 se utiliza para saber si fue ingresado o no el segundo operando
* \return resultado de la division
*/
float divicion(float,float,int,int);
//********************************************************
/** \brief Recibe el operando uno y el operando dos y calcula la multiplicacion
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
*  \param flag se utiliza para saber si fue ingresado o no el primer operando
*  \param flag1 se utiliza para saber si fue ingresado o no el segundo operando
* \return resultado de la multiplicacion
*/

float multiplicacion(float,float,int,int);
//********************************************************
/** \brief Recibe el operando uno y  calcula el factorial
*  \param Num1 es el Primero operando ingresado por el usuario
* \return resultado del factorial
*/
long long int factorial(float);
//********************************************************
/** \brief Recibe el operando uno y el operando dos y calcula todas las operaciones
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
*  \param flag se utiliza para saber si fue ingresado o no el primer operando
*  \param flag1 se utiliza para saber si fue ingresado o no el segundo operando
* \return resultado de todas las operaciones
*/

float todasOperaciones(float,float,int,int);
//********************************************************
/** \brief Verifica que se hallan ingresado los dos operandos
*  \param flag se utiliza para saber si fue ingresado o no el primer operando
*  \param flag1 se utiliza para saber si fue ingresado o no el segundo operando
* \return retorna si fueron ingresados los dos opeandos o no
*/
int validacionO(int,int);
//********************************************************
/** \brief Recibe el operando uno y verifica si el operando uno fue ingresado y si este es mayor a 0
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param flag se utiliza para saber si fue ingresado o no el primer operando
*  \param flag1 se utiliza para saber si fue ingresado o no el segundo operando
*  \param fac se utiliza para guardar el valor del factorial
* \return en caso de cumplir las condiciones retorna el factorial
*/
int validacionF2(int,int,float,long long int);
//********************************************************
/** \brief va modificando el menu a medida que se van cargando los valores
*  \param Num1 es el Primero operando ingresado por el usuario
*  \param Num2 es el Segundo operando ingresado por el usuario
*  \param flag se utiliza para saber si fue ingresado o no el primer operando
*  \param flag1 se utiliza para saber si fue ingresado o no el segundo operando
* \return el menu correspondiente a los valores cargados
*/

float menu(int,int,float,float);



#endif // FUNCIONES_H_INCLUDED
