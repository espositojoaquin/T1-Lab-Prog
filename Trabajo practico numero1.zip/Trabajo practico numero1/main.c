#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include "funciones.h"

int main()
{
    char seguir='s';
    int opcion=0;
    float num1;
    float num2;
    float sumar;
    float restar;
    float div;
    float multi;
    long long int fac;
    int val;
    int flag=0;
    int flag1=0;
    float TodasO;
    float men;

    system("color 4F");


    while(seguir=='s')
    {
        opcion= menu(flag,flag1,num1,num2);

        switch(opcion)
        {
        case 1:
            num1=ingresarNum(num1);
            flag=1;
            system("pause");
            system("cls");
             break;
        case 2:
            num2=ingresarNum(num2);
            flag1=1;
            system("pause");
            system("cls");

            break;
        case 3:

            sumar=suma(num1,num2,flag,flag1);
            system("pause");
            system("cls");

            break;
        case 4:
            restar=resta(num1,num2,flag,flag1);

            system("pause");
            system("cls");

            break;
        case 5:
            div=divicion(num1,num2,flag,flag1);
            system("pause");
            system("cls");

            break;
        case 6:
            multi=multiplicacion(num1,num2,flag,flag1);
            system("pause");
            system("cls");

            break;
        case 7:
            fac=factorial(num1);

            val=validacionF2(flag,flag1,num1,fac);
            break;
        case 8:
            TodasO=todasOperaciones(num1,num2,flag,flag1);
            break;
        case 9:
            seguir = 'n';
            break;
        }
    }
    return 0;
}
