
//#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

typedef struct {

    char nombre[50];
    int edad;
    int estado;
    int dni;

}EPersona;

/**
 * Obtiene el primer indice libre del array.
 * @param estructura de usuario
 * @param array de estructura
 * @return el primer indice disponible
 */
int EspacioLibre(EPersona[],int);

/**
 * Obtiene el indice que coincide con el dni pasado por parametro.
 * @param estructura de usuario
 * @param array de  estructura
 * @param dni el dni a ser buscado en el array.
 * @return el indice en donde se encuentra el elemento que coincide con el parametro dni
 */
 void BuscarDNI(EPersona[],int,int);
/**
 * Permite el registro de un nuevo usuario.
 * @param estructura de usuario
 * @param array de la estructura
 * @return El registro del Usuario cargado.
 */
void altaPersonas(EPersona gente[],int tam);
/**
 * Inicializa todos los estados a 0
 * @param estructura de usuario
 * @param array de la estructura
 * @return estado del Usuario inicializado
 */
void inicializarRP(EPersona gente[],int gent);
/**
 * Permite eliminar el registro de un usuario
 * @param estructura de usuario
 * @param array de la estructura
 * @return Si se produjo o no la eliminacion del Usuario
 */
void bajaPersonas(EPersona[],int);
/**
 * Permite listar los Usuarios en orden alfabetico
 * @param estructura de usuario
 * @param array de la estructura
 * @return lista de Usuarios ordenada alfabeticamente
 */
void ListaPersonas(EPersona[],int);

/**
 * Permite el ingreso de los datos del Usuario
 * @param estructura de usuario
 * @param array de la estructura
 * @return datos del usuario
 */
void IngresoDatos(EPersona[],int);

/**
 * Permite mostrar todos los usuarios cargados hasta el momento
 * @param estructura de usuario
 * @param array de la estructura
 * @return Todos los Usuarios con sus respectvos datos cargados
 */
void mostrar(EPersona[],int);
/**
 * Permite mostrar el Usuario que fue ingresado
 * @param estructura de usuario
 * @return Usuario ingresado
 */
void mostrarPersonaIgresada(EPersona gente);
/**
 * Verifica que la edad sea mayor a 0 y menor a una edad ilogica
 * @param estructura de usuario
 * @param array de la estructura
 * @return edad validada
 */
void validacionEdad(EPersona gente[],int);
/**
 * Carga automaticamente datos para poder utilizar el programa sin necesidad de ingresarlos por tecaldo
 * @param estructura de usuario
 * @param array de la estructura
 * @return lista de usuarios cargados.
 */
void HardCode(EPersona gente[],int tam);
/**
 * Cuenta la cantidad de usuarios que tienen 18 anios o menos
 * @param estructura de usuario
 * @param array de la estructura
 * @return Cantidad de Usuarios con 18 anios o menos
 */
int cont18(EPersona gente [],int);
/**
 * Cuenta la cantidad de usuarios que tienen entre 19 y 35 anios
 * @param estructura de usuario
 * @param array de la estructura
 * @return Cantidad de Usuarios entre 19 y 35
 */
int cont19(EPersona gente [],int);
/**
 * Cuenta la cantidad de usuarios que tienen mas de 35 anios
 * @param estructura de usuario
 * @param array de la estructura
 * @return Cantidad de Usuarios con mas de 35 anios
 */
int cont35(EPersona gente [],int);
/**
 * muestra un grafico de barras respresentado el rango por edad de los usuarios
 * @param estructura de usuario
 * @param array de la estructura
 * @return Rango de edades representado en un grafico
 */
void grafico(EPersona gente[],int);
/**
 * Verifica que el DNI se encuentre completo
 * @param estructura de usuario
 * @param array de la estructura
 * @return DNI validado
 */
void validacionDNI(EPersona[],int);


