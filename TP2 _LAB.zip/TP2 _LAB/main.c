#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "funciones.h"

#define TAM 20

int main()
{
    char seguir='s';
    int opcion=0;
    EPersona gente[TAM];
    inicializarRP(gente,TAM);
    system("color 4F");

    while(seguir=='s')
    {   printf("\t\tREGISTRO DE USUARIOS\n");
        printf("\n1- Agregar Usuario\n");
        printf("2- Borrar Usuario\n");
        printf("3- Imprimir lista ordenada por  nombre\n");
        printf("4- Imprimir grafico de edades\n");
        printf("5- Datos Harcodeados\n");
        printf("6- Salir\n");

        printf("\ningrese una opcion: ");

        scanf("%d",&opcion);
        system("pause");
        system("cls");
        while(opcion<1||opcion>6)
        {
            printf("Reingrese una opcion (1-6) :");

            scanf("%d",&opcion);
            system("pause");
            system("cls");

        }

        switch(opcion)
        {

        case 1:
            altaPersonas(gente,TAM);
            system("pause");
            system("cls");

            break;
        case 2:
            bajaPersonas(gente,TAM);
            system("pause");
            system("cls");
            break;
        case 3:
            ListaPersonas(gente,TAM);
            mostrar(gente,TAM);
            system("pause");
            system("cls");
            break;
        case 4:
            grafico(gente,TAM);
            system("pause");
            system("cls");
            break;
        case 5:
            HardCode(gente,TAM);
            system("pause");
            system("cls");
            break;
        case 6:
            seguir = 'n';
            break;
        }
    }

    return 0;
}
