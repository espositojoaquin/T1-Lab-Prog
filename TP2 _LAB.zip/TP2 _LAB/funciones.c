
#include "funciones.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

void altaPersonas(EPersona gente[],int tam)
{


    int EL;

    EL=EspacioLibre(gente,tam);
    if(EL==-1)
    {
        printf("No hay mas espacio disponible \n");

    }
    else
    {
        IngresoDatos(gente,tam);

    }


}

//*************************************************
void inicializarRP(EPersona gente[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        gente[i].estado=0;
    }

}
//*************************************************
void bajaPersonas(EPersona gente[],int TAM)
{
    int i;
    int aux;
    char respuesta='s';

    printf("Ingrese el documento del usuario que desea dar la baja\n");
    scanf("%d",&aux);
    BuscarDNI(gente,TAM,aux);
}

//***************************************************
void ListaPersonas(EPersona gente[],int tam)
{
    int i,k;
    EPersona auxP;
    for(i=0; i<tam-1; i++)
    {
        for(k=i+1; k<tam; k++)
        {
            if(strcmp(gente[i].nombre,gente[k].nombre)>0)
            {
                auxP=gente[i];
                gente[i]=gente[k];
                gente[k]=auxP;

            }



        }

    }
}


//*********************************************************
int EspacioLibre(EPersona gente[],int tam)
{
    int i;
    int flag= -1;
    for(i=0; i<tam; i++)
    {
        if(gente[i].estado==0)
        {
            flag=i;
            break;
        }
    }
    return flag;
}
//***************************************************************
void IngresoDatos(EPersona gente[],int tam)
{

    int i;
    int aux;
    int cont18=0;
    int cont19=0;
    int cont35=0;
    for(i=0; i<tam; i++)
    {
        if(gente[i].estado==0)
        {
            printf("\nPor favor ingrese su nombre: ");
            fflush(stdin);
            gets(gente[i].nombre);
            printf("\ningrese su dni: ");
            scanf("%d",&gente[i].dni);
            validacionDNI(gente,tam);
            printf("\ningrese su edad: ");
            scanf("%d",&gente[i].edad);
            validacionEdad(gente,tam);
            gente[i].estado=1;
            mostrarPersonaIgresada(gente[i]);

            break;
        }
    }





}
//*********************************************************************************
void BuscarDNI(EPersona gente[],int TAM,int aux)
{
    int i;

    char respuesta='s';
    for(i=0; i<TAM; i++)
    {
        if(aux==gente[i].dni)
        {
            printf(" Desea eliminar este usuario?(s/n)\n %s---%d---%d \n",gente[i].nombre,gente[i].dni,gente[i].edad);
            fflush(stdin);
            respuesta=getch();
            while(respuesta!='s'&&respuesta!='n')
            {
                printf("Por favor responda (s/n)\n");
                fflush(stdin);
                respuesta=getch();
                system("pause");
                system("cls");
            }
               if(respuesta=='s')
                {
                    gente[i].estado=0;
                    printf("Usuario eliminado con exito\n");
                    break;
                }
                else
                {
                    printf("Accion cancelada por el usuario\n");
                    break;
                }
        }
        else if(aux!=gente[i].dni)
        {
            printf("DNI inexistente\n");
            break;
        }
    }
}
//**************************************************
void mostrar(EPersona gente[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        if(gente[i].estado==1)
        {
            mostrarPersonaIgresada(gente[i]);

        }

    }
}
void mostrarPersonaIgresada(EPersona gente)
{
    printf("\n%s\t%d\t%d\n",gente.nombre,gente.dni,gente.edad);
}

void validacionEdad(EPersona gente[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {

        while(gente[i].edad<1||gente[i].edad>120)
        {
            printf("introduzca una edad valida: ");
            fflush(stdin);
            scanf("%d",&gente[i].edad);

        }

        break;
    }
}
//******************************************************
void validacionDNI(EPersona gente[],int tam)
{
    int i;
     for(i=0; i<tam; i++)
    {

        while(gente[i].dni<999999||gente[i].dni>99000000)
        {
            printf("introduzca un documento valido: ");
            fflush(stdin);
            scanf("%d",&gente[i].dni);

        }

        break;
    }
}

//******************************************************

void HardCode(EPersona gente[],int tam)
{
    int edad[20]= {10,11,20,21,22,40,47,5,17,65,33,37,15,26,28,29,25,14,36,45};
    char nombre[20][50]= {"Juan","Maria","Pedro","Julian","Martina","Julio","Kevin","Joaquin","Leonel","Brenda","Aldana","Luz","Agustin","Angel","Brian","Gladys","Ruben","Luis","Claudia","Vanina"};
    int dni[20]= {40929964,40929954,40929966,40929969,47929964,40929914,40929963,48929964,41929964,42929964,43929964,44929964,45929964,46929964,40129964,40229964,41329964,40929644,40926984,40929147};
    int cont18m;
    int cont19m;
    int cont35m;

    int i;
    printf("\t\PERSONAS\n");

    for(i=0; i<tam; i++)
    {
        gente[i].dni=dni[i];
        strcpy(gente[i].nombre,nombre[i]);
        gente[i].edad=edad[i];

        gente[i].estado=1;

      cont18m=cont18(gente,tam);
      cont19m=cont19(gente,tam);
      cont35m=cont35(gente,tam);


        if(gente[i].estado!=0)
        {
            mostrarPersonaIgresada(gente[i]);
        }




    }

}
//*********************************************************

int cont18(EPersona gente [],int tam)
{
    int i;
    int cont18=0;
    for(i=0; i<tam; i++)
    {
        if(gente[i].estado==1&&gente[i].edad<19)
        {
            cont18++;

        }
    }
    return cont18;
}
//******************************************************
int cont19(EPersona gente [],int tam)
{
    int i;
    int cont19=0;
    for(i=0; i<tam; i++)
    {
        if(gente[i].estado==1&&gente[i].edad>18&&gente[i].edad<36)
        {
            cont19++;

        }
    }
    return cont19;
}
//************************************************************
int cont35(EPersona gente [],int tam)
{
    int i;
    int cont35=0;
    for(i=0; i<tam; i++)
    {
        if(gente[i].estado==1&&gente[i].edad>35)
        {
            cont35++;

        }
    }
    return cont35;
}
//***********************************************************
void grafico(EPersona gente[],int tam)
{
    int i;
    int cont18m;
    int cont19m;
    int cont35m;
    int flag1=0;
    int mayor;

    cont18m=cont18(gente,tam);
    cont19m=cont19(gente,tam);
    cont35m=cont35(gente,tam);

    if(cont18m>=cont19m&&cont18m>=cont35m)
     {
         mayor=cont18m;
     }

   else
    {
         if(cont19m>=cont18m&&cont19m>=cont35m)
         {
             mayor=cont19m;
         }
         else
         {

            mayor=cont35m;
         }
    }

     for(i=mayor;i>0;i--)
     {
         if(i<10)
         {
             printf("%02d|",i);
         }
         else
         {
             printf("%02d|",i);
         }

         if(i<=cont18m)
         {
             printf("*");
         }
         if(i<=cont19m)
         {
             flag1=1;
             printf("\t*");
         }
         if(i<=cont35m)
         {
             if(flag1==0)
             {
                 printf("\t\t*");
             }
             else
             {
                 if(flag1==1)
                 {
                     printf("\t*");
                 }
             }
         }
         printf("\n");
     }


       printf("--+-----------------");
       printf("\n |<18\t19-35\t>35 \n");
}


