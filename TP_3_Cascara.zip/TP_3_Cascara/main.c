#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "funciones.h"
#include <string.h>
#define ARCH /C:/Users/JOAKO/Desktop/TP3/TP_3_Cascara/peliculas.html
#define TAM 10

int main()
{
    char seguir='s';
    int opcion=0;
    EMovie movie[TAM];
    EMovie* mov=&movie[0];
    inicializarPeli(mov,TAM);
    cargarBinario(mov,TAM);
    system("color C");
     printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tNETFLIX\n\n\n\n\n\n\n\n\n\n");
     printf("Si quiere ingresar: ");
     system("pause");
     system("cls");
    system("color 4F");

    while(seguir=='s')
    {

        printf("1- Agregar pelicula\n");
        printf("2- Borrar pelicula\n");
        printf("3- Modificar pelicula\n");
        printf("4- Generar pagina web\n");
        printf("5- Listar\n");
        printf("6- Salir\n");
        printf("Ingrese una opcion: ");
        scanf("%d",&opcion);

        system("pause");
        system("cls");


        switch(opcion)
        {
        case 1: //altaPeli(movie,TAM);
            altaPelis(mov,TAM);
            guardarBinario(mov,TAM);
            system("pause");
            system("cls");

            break;
        case 2:
            borrarPeli(mov,TAM);
            guardarBinario(mov,TAM);
            system("pause");
            system("cls");
            break;
        case 3:
            modificarPeli(mov,TAM);
            guardarBinario(mov,TAM);
            system("pause");
            system("cls");
            break;
        case 4:
            GenerarPag(mov,TAM);
            system("pause");
            system("cls");
            break;
        case 5:
            mostrar(mov,TAM);
            system("pause");
            system("cls");
            break;
        case 6:
            seguir = 'n';
            break;
        default:
            {

                printf("\nIngrese una opcion entre 1-6: ");
                scanf("%d",&opcion);
                system("pause");
                system("cls");


            }


        }
    }
    return 0;
}


