#include "funciones.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <string.h>


//********************************************************************************
int EspacioLibre(EMovie* movie,int tam)
{
    int i;
    int flag=-1;
    for(i=0; i<tam; i++)
    {
        if((movie+i)->estado==-1)
        {
            flag=i;
            break;
        }
    }
    return flag;
}
//**********************************************************************************
void inicializarPeli(EMovie* peli,int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        strcpy((peli+i)->titulo,"");
        strcpy((peli+i)->genero,"");
        (peli+i)->duracion=-1;
        strcpy((peli+i)->descripcion,"");
        (peli+i)->puntaje=-1;
        strcpy((peli+i)->linkImagen,"");
        (peli+i)->id=-1;
        (peli+i)->estado=-1;

    }
}

//**********************************************************************************
void IngresoDatos(EMovie* movie,int tam)
{

    int i,j,auxid;


    for(i=0; i<tam; i++)
    {
        if((movie+i)->estado==-1)
        {

            printf("Ingrese el titulo de la pelicula: ");
            fflush(stdin);
            gets((movie+i)->titulo);

            while(strlen((movie+i)->titulo)>50)
            {
                printf("\nPor favor ingrese un titulo mas corto:\n");
                fflush(stdin);
                gets((movie+i)->titulo);
                system("pause");
                system("cls");

            }
            printf("Ingrese el genero de la peliluca: ");
            fflush(stdin);
            gets((movie+i)->genero);
            while(strlen((movie+i)->genero)>19)
            {
                printf("\nPor favor ingrese un Genero mas acotado:\n");
                fflush(stdin);
                gets((movie+i)->genero);
                system("pause");
                system("cls");

            }
            printf("Ingrese la duracion de la pelicula en minutos: ");
            scanf("%d",&(movie+i)->duracion);
            while((movie+i)->duracion>420||(movie+i)->duracion<30)
            {
                printf("\nIngrese una duracion coherente: ");
                scanf("%d",&(movie+i)->duracion);
                system("pause");
                system("cls");

            }
            printf("Ingrese la descripcion de la pelicula: ");
            fflush(stdin);
            gets((movie+i)->descripcion);
            while(strlen((movie+i)->descripcion)>49)
            {
                printf("\nPor favor ingrese una descripcion  mas corta:\n");
                fflush(stdin);
                gets((movie+i)->descripcion);
                system("pause");
                system("cls");

            }
            printf("Ingrese el puntaje de la pelicula(1-10): ");
            scanf("%d",&(movie+i)->puntaje);
            while((movie+i)->puntaje<1||(movie+i)->puntaje>10)
            {
                printf("Ingrese el puntaje de la pelicula entre 1 y 10: ");
                scanf("%d",&(movie+i)->puntaje);
                system("pause");
                system("cls");
            }
            printf("Ingrese el link de la pelicula: ");
            fflush(stdin);
            gets((movie+i)->linkImagen);

            while(strlen((movie+i)->linkImagen)>200)
            {
                printf("\nPor favor ingrese un link mas corto:\n");
                fflush(stdin);
                gets((movie+i)->linkImagen);
                system("pause");
                system("cls");

            }
            printf("Ingrese el Codigo de Identificacion de la pelicula(100-1000): ");
            scanf("%d",&(movie+i)->id);
            while((movie+i)->id<100||(movie+i)->id>1000)
            {
                printf("Ingrese el Codigo de Identificacion de la pelicula entre (100-1000): ");
                scanf("%d",&(movie+i)->id);
            }
            for(j=0; j<tam; j++)
            {
                if((movie+j)->estado!=-1)
                {

                    while((movie+i)->id==(movie+j)->id)
                    {
                        printf("\nEste Codigo ya fue registrado Por favor ingrese otro: ");
                        scanf("%d",&(movie+i)->id);
                        system("pause");
                        system("cls");
                    }

                }


            }

            (movie+i)->estado=1;

            printf("\n\t\tPELICULA INGRESADA\n\t\n");


            mostrarPeli((movie+i));

            break;
        }

    }

}
//******************************************************************************
void mostrar(EMovie* movie,int tam)
{
    int i;
    printf("\n\t\tPELICULAS REGISTRADAS\t\t\n");
    for(i=0; i<tam; i++)
    {
        if((movie+i)->estado!=-1)
        {
            printf("\n\nLink de imagen: %s\nTitulo: %s\nGenero: %s\nDuracion: %d\nDescripcion: %s\nValoracion: %d\nCodigo Peli: %d\n\n",(movie+i)->linkImagen,(movie+i)->titulo,(movie+i)->genero,(movie+i)->duracion,(movie+i)->descripcion,(movie+i)->puntaje,(movie+i)->id);

        }

    }



}
//******************************************************************************

void altaPelis(EMovie* movie,int tam)
{

    int EL;

    EL=EspacioLibre(movie,tam);
    if(EL==-1)
    {
        printf("No hay mas espacio disponible \n");

    }

    else
    {
        IngresoDatos(movie,tam);

    }


}
//***********************************************************
void mostrarPeli(EMovie* movie)
{
    printf("Link de imagen: %s\nTitulo: %s\nGenero: %s \nDuracion: %d \nDescripcion: %s\nValoracion: %d\nCodigo Peli: %d\n",(movie)->linkImagen,(movie)->titulo,(movie)->genero,(movie)->duracion,(movie)->descripcion,(movie)->puntaje,(movie)->id);

}
//***********************************************************
void borrarPeli(EMovie* movie,int tam)
{
    int i;
    int flag=0;
    int aux;

    char respuesta='s';
    printf("\nPor favor ingrese el numero de indentificacion de la pelicula: ");
    scanf("%d",&aux);
    for(i=0; i<tam; i++)
    {
        if(aux==(movie+i)->id)
        {
            if((movie+i)->estado!= -1)
            {
                flag=1;
                printf(" Desea eliminar este Film?(s/n)\n %s \n",(movie+i)->titulo);
                fflush(stdin);
                respuesta=getch();
                while(respuesta!='s'&&respuesta!='n')
                {
                    printf("Por favor responda (s/n)\n");
                    fflush(stdin);
                    respuesta=getch();
                    system("pause");
                    system("cls");
                }
                if(respuesta=='s')
                {
                    (movie+i)->estado= -1;

                    printf("Pelicula eliminada con exito\n");
                    system("pause");
                    system("cls");
                    break;
                }
                else
                {
                    printf("Accion cancelada por el usuario\n");
                    system("pause");
                    system("cls");
                    break;
                }
            }
        }


    }
    if(flag==0)
    {
        printf(" Pelicula inexistente\n");
        system("pause");
        system("cls");

    }

}
void modificarPeli(EMovie* movie,int tam)
{
    int i,j;
    int flag=0;
    int aux,auxid;

    char respuesta='s';
    printf("\nPor favor ingrese el numero de indentificacion de la pelicula: ");
    scanf("%d",&aux);
    for(i=0; i<tam; i++)
    {
        if(aux==(movie+i)->id)
        {
            if((movie+i)->estado!= -1)
            {
                flag=1;
                printf(" Desea modificar este Film?(s/n)\n %s \n",(movie+i)->titulo);
                fflush(stdin);
                respuesta=getch();
                while(respuesta!='s'&&respuesta!='n')
                {
                    printf("Por favor responda (s/n)\n");
                    fflush(stdin);
                    respuesta=getch();
                    system("pause");
                    system("cls");
                }
                if(respuesta=='s')
                {

                    if((movie+i)->estado!=-1)
                    {

                        printf("Ingrese el titulo de la pelicula: ");
                        fflush(stdin);
                        gets((movie+i)->titulo);

                        while(strlen((movie+i)->titulo)>50)
                        {
                            printf("\nPor favor ingrese un titulo mas corto:\n");
                            fflush(stdin);
                            gets((movie+i)->titulo);
                            system("pause");
                            system("cls");

                        }
                        printf("Ingrese el genero de la peliluca: ");
                        fflush(stdin);
                        gets((movie+i)->genero);
                        while(strlen((movie+i)->genero)>19)
                        {
                            printf("\nPor favor ingrese un Genero mas acotado:\n");
                            fflush(stdin);
                            gets((movie+i)->genero);
                            system("pause");
                            system("cls");

                        }
                        printf("Ingrese la duracion de la pelicula en minutos: ");
                        scanf("%d",&(movie+i)->duracion);
                        while((movie+i)->duracion>420||(movie+i)->duracion<30)
                        {
                            printf("\nIngrese una duracion coherente: ");
                            scanf("%d",&(movie+i)->duracion);
                            system("pause");
                            system("cls");

                        }
                        printf("Ingrese la descripcion de la pelicula: ");
                        fflush(stdin);
                        gets((movie+i)->descripcion);
                        while(strlen((movie+i)->descripcion)>49)
                        {
                            printf("\nPor favor ingrese una descripcion  mas corta:\n");
                            fflush(stdin);
                            gets((movie+i)->descripcion);
                            system("pause");
                            system("cls");

                        }
                        printf("Ingrese el puntaje de la pelicula(1-10): ");
                        scanf("%d",&(movie+i)->puntaje);
                        while((movie+i)->puntaje<1||(movie+i)->puntaje>10)
                        {
                            printf("Ingrese el puntaje de la pelicula entre 1 y 10: ");
                            scanf("%d",&(movie+i)->puntaje);
                            system("pause");
                            system("cls");
                        }
                        printf("Ingrese el link de la pelicula: ");
                        fflush(stdin);
                        gets((movie+i)->linkImagen);

                        while(strlen((movie+i)->linkImagen)>200)
                        {
                            printf("\nPor favor ingrese un link mas corto:\n");
                            fflush(stdin);
                            gets((movie+i)->linkImagen);
                            system("pause");
                            system("cls");

                        }


                        printf("Pelicula modificada con exito\n");
                        system("pause");
                        system("cls");
                        break;
                    }
                    else
                    {
                        printf("Accion cancelada por el usuario\n");
                        system("pause");
                        system("cls");
                        break;
                    }
                }

            }

        }


    }
    if(flag==0)
    {
        printf(" Pelicula inexistente\n");
        system("pause");
        system("cls");

    }

}
//******************************************************************
void GenerarPag(EMovie* movie,int tam)
{

    int i;
    FILE* PELI;

    PELI=fopen("C:peliculas.html","w+");
    if(PELI==NULL)
    {
        printf("\nError al abrir el archivo\n");
        exit(1);
    }
    for(i=0; i<tam; i++)
    {
        if((movie+i)->estado!=-1)
        {

            fprintf(PELI,"<article class='col-md-4 article-intro'>\
                    <a href='#'>\
                    <img class='img-responsive img-rounded' src='%s'\
                    alt=''>\
                    </a>\
                    <h3>\
                    <a href='#'>%s</a>\
                    </h3>\
                    <ul>\
                    <li>G�nero:%s</li>\
                    <li>Puntaje:%d</li>\
                    <li>Duraci�n:%d</li>\
                    </ul>\
                    <p>%s.</p>\
                    </article>",(movie+i)->linkImagen,(movie+i)->titulo,(movie+i)->genero,(movie+i)->puntaje,(movie+i)->duracion,(movie+i)->descripcion);


        }


    }
    printf("\nArchivo creado con exito!\n");

    fclose(PELI);

}
//*********************************************************************************
int cargarBinario(EMovie* movie,int tam)
{
    int retorno=-1;
    FILE* pPelis;
    pPelis=fopen("bin.dat","rb");
    if(pPelis==NULL)
    {
        pPelis=fopen("bin.dat","wb");
        if(pPelis==NULL)
        {
            printf("No se pudo abrir el archivo");
            system("pause");
            return retorno;
        }
    }
    fread(movie,sizeof(EMovie),tam,pPelis);
    retorno=0;
    fclose(pPelis);
    return retorno;
}
//*****************************************************************
void guardarBinario(EMovie* movie,int tam)
{
    FILE* pPelis;
    pPelis=fopen("bin.dat","wb");
    if(pPelis==NULL)
    {
        printf("Error al abrir el archivo binario\n");
        exit(1);
    }
    fwrite(movie,sizeof(EMovie),tam,pPelis);
    printf("\nArchivo binario guardado con exito!\n");
    fclose(pPelis);
}
//****************************************************************

int ValidarId(EMovie* movie,int tam,int aux)
{
    int i,flag=0;

    while(aux<100||aux>1000)
    {
        flag=2;

    }

    for(i=0; i<tam; i++)
    {
        if((movie+i)->estado!=-1)
        {

            while(aux==(movie+i)->id)
            {
                flag=1;
            }

        }


    }
    return flag;
}
